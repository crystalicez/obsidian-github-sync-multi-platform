import assert from "node:assert/strict";
import test from "node:test";

import {
  V4ProgressStore,
  formatV4Duration,
  formatV4PhaseTiming,
  middleTruncateV4Path,
  remainingV4Progress,
  type V4SyncProgressPatch,
  type V4SyncProgressSnapshot,
} from "../../src/lib/v4/progress";

function createProgressFixture() {
  let monotonicNow = 0;
  let nextHandle = 1;
  const scheduled = new Map<number, { callback: () => void; delay: number }>();
  const cancelled: number[] = [];
  const store = new V4ProgressStore({
    throttleMs: 400,
    timingRefreshMs: 1_000,
    schedule: (callback, delay) => {
      const handle = nextHandle++;
      scheduled.set(handle, { callback, delay });
      return handle;
    },
    cancel: handle => {
      cancelled.push(handle as number);
      scheduled.delete(handle as number);
    },
    monotonicNow: () => monotonicNow,
  });
  return {
    store,
    scheduled,
    cancelled,
    setNow(value: number) { monotonicNow = value; },
    runScheduledCallbackAt(delay: number) {
      const entry = [...scheduled.entries()].find(([, value]) => value.delay === delay);
      assert.ok(entry, `no callback scheduled at ${delay}ms`);
      scheduled.delete(entry[0]);
      entry[1].callback();
    },
  };
}

function createAdvancingClockFixture() {
  let now = 0;
  let clockCalls = 0;
  const scheduled = new Map<number, { callback: () => void; delay: number }>();
  let nextHandle = 1;
  const store = new V4ProgressStore({
    throttleMs: 400,
    timingRefreshMs: 1_000,
    schedule: (callback, delay) => {
      const handle = nextHandle++;
      scheduled.set(handle, { callback, delay });
      return handle;
    },
    cancel: handle => { scheduled.delete(handle as number); },
    monotonicNow: () => {
      clockCalls += 1;
      now += 100;
      return now;
    },
  });
  return { store, scheduled, clockCalls: () => clockCalls };
}

test("phase changes publish immediately while path and counters throttle", () => {
  const { store, scheduled, runScheduledCallbackAt } = createProgressFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.subscribe(snapshot => seen.push(snapshot));
  store.update({ lifecycle: "active", phase: "checking-remote", operation: "normal", trigger: "manual" });
  store.update({ phase: "scanning-local", currentPath: "A.md" });
  store.update({ currentPath: "B.md", pull: { completed: 1, total: 3 } });
  store.update({ currentPath: "C.md", pull: { completed: 2, total: 3 } });

  assert.equal(seen.at(-1)?.currentPath, "A.md");
  assert.equal([...scheduled.values()].some(item => item.delay === 400), true);
  runScheduledCallbackAt(400);
  assert.equal(seen.at(-1)?.currentPath, "C.md");
  assert.deepEqual(seen.at(-1)?.pull, { completed: 2, total: 3 });
});

test("the default path and counter throttle is exactly 400 milliseconds", () => {
  const scheduledDelays: number[] = [];
  const store = new V4ProgressStore({
    schedule: (_callback, delay) => {
      scheduledDelays.push(delay);
      return scheduledDelays.length;
    },
    cancel: () => undefined,
    monotonicNow: () => 0,
  });
  store.beginRun({ phase: "uploading", currentPath: "A.md" });
  store.update({ currentPath: "B.md", push: { completed: 1 } });

  assert.deepEqual(scheduledDelays, [1_000, 400]);
});

test("a phase transition flushes the pending path before publishing the next phase", () => {
  const { store } = createProgressFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.subscribe(snapshot => seen.push(snapshot));
  store.update({ lifecycle: "active", phase: "hashing", currentPath: "A.md" });
  store.update({ currentPath: "B.md" });
  store.update({ phase: "encrypting", currentPath: "B.md" });
  assert.deepEqual(seen.slice(-2).map(item => [item.phase, item.currentPath]), [
    ["hashing", "B.md"],
    ["encrypting", "B.md"],
  ]);
});

test("a phase transition uses one atomic timestamp while flushing pending sensitive state", () => {
  const { store, clockCalls } = createAdvancingClockFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.beginRun({ phase: "uploading", currentPath: "A.md" });
  store.subscribe(snapshot => seen.push(snapshot));
  store.update({ currentPath: "B.md" });

  store.update({ phase: "committing", currentPath: "C.md" });

  assert.equal(clockCalls(), 3);
  assert.deepEqual(seen.slice(-2).map(snapshot => ({
    phase: snapshot.phase,
    path: snapshot.currentPath,
    uploadingElapsedMs: snapshot.timings.find(timing => timing.phase === "uploading")?.elapsedMs,
    totalElapsedMs: snapshot.totalElapsedMs,
  })), [
    { phase: "uploading", path: "B.md", uploadingElapsedMs: 200, totalElapsedMs: 200 },
    { phase: "committing", path: "C.md", uploadingElapsedMs: 200, totalElapsedMs: 200 },
  ]);
});

test("a terminal update closes at its atomic timestamp without a preceding timing regression", () => {
  const { store, clockCalls } = createAdvancingClockFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.beginRun({ phase: "uploading", currentPath: "A.md" });
  store.subscribe(snapshot => seen.push(snapshot));
  store.update({ currentPath: "B.md" });

  store.update({ lifecycle: "success", currentPath: "C.md" });

  assert.equal(clockCalls(), 3);
  assert.deepEqual(seen.slice(-2).map(snapshot => ({
    lifecycle: snapshot.lifecycle,
    path: snapshot.currentPath,
    elapsedMs: snapshot.timings[0]?.elapsedMs,
    totalElapsedMs: snapshot.totalElapsedMs,
  })), [
    { lifecycle: "active", path: "B.md", elapsedMs: 200, totalElapsedMs: 200 },
    { lifecycle: "success", path: "C.md", elapsedMs: 200, totalElapsedMs: 200 },
  ]);
});

test("finish closes at its one accepted atomic timestamp while flushing pending sensitive state", () => {
  const { store, clockCalls } = createAdvancingClockFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.beginRun({ phase: "uploading", currentPath: "A.md" });
  store.subscribe(snapshot => seen.push(snapshot));
  store.update({ currentPath: "B.md" });

  store.finish("success", { currentPath: "C.md" });

  assert.equal(clockCalls(), 3);
  assert.deepEqual(seen.slice(-2).map(snapshot => ({
    lifecycle: snapshot.lifecycle,
    path: snapshot.currentPath,
    elapsedMs: snapshot.timings[0]?.elapsedMs,
    totalElapsedMs: snapshot.totalElapsedMs,
  })), [
    { lifecycle: "active", path: "B.md", elapsedMs: 200, totalElapsedMs: 200 },
    { lifecycle: "success", path: "C.md", elapsedMs: 200, totalElapsedMs: 200 },
  ]);
});

test("public flush keeps sensitive progress throttled until the scheduler boundary", () => {
  const { store, scheduled, cancelled, setNow, runScheduledCallbackAt } = createProgressFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 2 } });
  store.subscribe(snapshot => seen.push(snapshot));
  setNow(100);
  store.update({ currentPath: "B.md", push: { completed: 1 } });

  setNow(250);
  store.flush();

  assert.equal(store.snapshot.currentPath, "A.md");
  assert.deepEqual(store.snapshot.push, { completed: 0, total: 2 });
  assert.equal(store.snapshot.timings[0].elapsedMs, 250);
  assert.equal([...scheduled.values()].some(item => item.delay === 400), true);
  assert.equal(cancelled.length, 0);
  assert.equal(seen.at(-1)?.currentPath, "A.md");

  let initialForLateSubscriber: V4SyncProgressSnapshot | undefined;
  store.subscribe(snapshot => { initialForLateSubscriber ??= snapshot; });
  assert.equal(initialForLateSubscriber?.currentPath, "A.md");
  assert.deepEqual(initialForLateSubscriber?.push, { completed: 0, total: 2 });

  setNow(500);
  runScheduledCallbackAt(400);
  assert.equal(store.snapshot.currentPath, "B.md");
  assert.deepEqual(store.snapshot.push, { completed: 1, total: 2 });
  assert.equal(store.snapshot.timings[0].elapsedMs, 500);
});

test("dispose still cancels both timers after a public flush preserves the pending throttle", () => {
  const { store, scheduled, cancelled, setNow } = createProgressFixture();
  store.beginRun({ phase: "uploading", currentPath: "A.md" });
  setNow(100);
  store.update({ currentPath: "B.md" });
  setNow(250);
  store.flush();

  assert.equal(scheduled.size, 2);
  store.dispose();
  assert.equal(scheduled.size, 0);
  assert.equal(cancelled.length, 2);
});

test("normalization clamps counts and computes remaining only for known totals", () => {
  const { store } = createProgressFixture();
  store.update({ lifecycle: "active", phase: "uploading", push: { completed: 7, total: 5 } });
  assert.deepEqual(store.snapshot.push, { completed: 5, total: 5 });
  assert.equal(remainingV4Progress(store.snapshot.push), 0);
  assert.equal(remainingV4Progress({ completed: 2 }), undefined);
});

test("phase timing aggregates retries with a monotonic clock", () => {
  const { store, setNow } = createProgressFixture();
  store.beginRun({ phase: "checking-remote", attempt: 1 });
  setNow(600);
  store.update({ phase: "scanning-local" });
  setNow(1_000);
  store.update({ phase: "checking-remote", attempt: 2 });
  setNow(2_800);
  store.finish("success", { lastSyncTime: 123 });

  assert.deepEqual(store.snapshot.timings, [
    { phase: "checking-remote", elapsedMs: 2_400, occurrences: 2 },
    { phase: "scanning-local", elapsedMs: 400, occurrences: 1 },
  ]);
  assert.equal(store.snapshot.totalElapsedMs, 2_800);
});

test("active timing refreshes once per second and terminal transition flushes exact time", () => {
  const { store, setNow, runScheduledCallbackAt } = createProgressFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.subscribe(snapshot => seen.push(snapshot));
  store.beginRun({ phase: "encrypting" });
  setNow(1_000);
  runScheduledCallbackAt(1_000);
  assert.equal(seen.at(-1)?.timings[0].elapsedMs, 1_000);
  setNow(1_250);
  store.finish("success", { lastSyncTime: 999 });
  assert.equal(store.snapshot.timings[0].elapsedMs, 1_250);
});

test("timing publications never move backward when the supplied clock regresses", () => {
  const { store, setNow, runScheduledCallbackAt } = createProgressFixture();
  store.beginRun({ phase: "encrypting" });

  const observed: Array<[phase: number, total: number]> = [];
  for (const now of [1_000, 500, 1_200]) {
    setNow(now);
    runScheduledCallbackAt(1_000);
    observed.push([store.snapshot.timings[0].elapsedMs, store.snapshot.totalElapsedMs]);
  }

  assert.deepEqual(observed, [
    [1_000, 1_000],
    [1_000, 1_000],
    [1_200, 1_200],
  ]);
});

test("the default clock prefers performance.now without consulting wall time", () => {
  const performanceDescriptor = Object.getOwnPropertyDescriptor(globalThis, "performance");
  const originalDateNow = Date.now;
  let performanceCalls = 0;
  Object.defineProperty(globalThis, "performance", {
    configurable: true,
    value: { now: () => { performanceCalls += 1; return 123; } },
  });
  Date.now = () => { throw new Error("wall time must not be used when performance.now is available"); };

  try {
    const store = new V4ProgressStore();
    assert.doesNotThrow(() => store.beginRun({ phase: "planning" }));
    assert.equal(performanceCalls, 1);
    store.dispose();
  } finally {
    Date.now = originalDateNow;
    if (performanceDescriptor) Object.defineProperty(globalThis, "performance", performanceDescriptor);
    else Reflect.deleteProperty(globalThis, "performance");
  }
});

test("a timing refresh cannot publish path or counter changes before the throttle boundary", () => {
  const { store, setNow, runScheduledCallbackAt } = createProgressFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.subscribe(snapshot => seen.push(snapshot));
  store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 2 } });

  setNow(900);
  store.update({ currentPath: "B.md", push: { completed: 1 } });
  setNow(1_000);
  runScheduledCallbackAt(1_000);

  assert.equal(seen.at(-1)?.timings[0].elapsedMs, 1_000);
  assert.equal(seen.at(-1)?.currentPath, "A.md");
  assert.deepEqual(seen.at(-1)?.push, { completed: 0, total: 2 });

  setNow(1_300);
  runScheduledCallbackAt(400);
  assert.equal(seen.at(-1)?.currentPath, "B.md");
  assert.deepEqual(seen.at(-1)?.push, { completed: 1, total: 2 });
});

test("metadata publications and new subscribers cannot bypass a pending throttle", () => {
  const { store, setNow, runScheduledCallbackAt } = createProgressFixture();
  const seen: V4SyncProgressSnapshot[] = [];
  store.subscribe(snapshot => seen.push(snapshot));
  store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 2 } });

  setNow(900);
  store.update({ currentPath: "B.md", push: { completed: 1 } });
  store.update({ attempt: 2 });
  assert.equal(seen.at(-1)?.attempt, 2);
  assert.equal(seen.at(-1)?.currentPath, "A.md");
  assert.deepEqual(seen.at(-1)?.push, { completed: 0, total: 2 });

  let initialForLateSubscriber: V4SyncProgressSnapshot | undefined;
  store.subscribe(snapshot => { initialForLateSubscriber ??= snapshot; });
  assert.equal(initialForLateSubscriber?.currentPath, "A.md");
  assert.deepEqual(initialForLateSubscriber?.push, { completed: 0, total: 2 });

  setNow(1_300);
  runScheduledCallbackAt(400);
  assert.equal(seen.at(-1)?.currentPath, "B.md");
  assert.deepEqual(seen.at(-1)?.push, { completed: 1, total: 2 });
});

for (const scenario of [
  {
    name: "an unchanged phase with path and counter changes",
    arrange: (_store: V4ProgressStore) => undefined,
    update: { phase: "uploading", currentPath: "B.md", push: { completed: 1 } } as V4SyncProgressPatch,
    expectedPath: "B.md",
    expectedCompleted: 1,
  },
  {
    name: "an unchanged lifecycle with path and counter changes",
    arrange: (_store: V4ProgressStore) => undefined,
    update: { lifecycle: "active", currentPath: "B.md", push: { completed: 1 } } as V4SyncProgressPatch,
    expectedPath: "B.md",
    expectedCompleted: 1,
  },
  {
    name: "attempt metadata mixed with path and counter changes",
    arrange: (_store: V4ProgressStore) => undefined,
    update: { attempt: 2, currentPath: "B.md", push: { completed: 1 } } as V4SyncProgressPatch,
    expectedPath: "B.md",
    expectedCompleted: 1,
  },
  {
    name: "mixed metadata and sensitive changes while a throttle is already pending",
    arrange: (store: V4ProgressStore) => store.update({ currentPath: "B.md", push: { completed: 1 } }),
    update: { attempt: 2, currentPath: "C.md", push: { completed: 2 } } as V4SyncProgressPatch,
    expectedPath: "C.md",
    expectedCompleted: 2,
  },
]) {
  test(`${scenario.name} retains eligible sensitive fields until exactly 400 milliseconds`, () => {
    const { store, setNow, runScheduledCallbackAt } = createProgressFixture();
    const seen: V4SyncProgressSnapshot[] = [];
    store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 3 } });
    store.subscribe(snapshot => seen.push(snapshot));

    scenario.arrange(store);
    store.update(scenario.update);

    assert.equal(store.snapshot.currentPath, "A.md");
    assert.deepEqual(store.snapshot.push, { completed: 0, total: 3 });
    assert.equal(seen.at(-1)?.currentPath, "A.md");
    assert.deepEqual(seen.at(-1)?.push, { completed: 0, total: 3 });

    let initialForLateSubscriber: V4SyncProgressSnapshot | undefined;
    store.subscribe(snapshot => { initialForLateSubscriber ??= snapshot; });
    assert.equal(initialForLateSubscriber?.currentPath, "A.md");
    assert.deepEqual(initialForLateSubscriber?.push, { completed: 0, total: 3 });

    const publicationsBeforeMetadata = seen.length;
    store.update({ attempt: 9 });
    assert.equal(seen.length, publicationsBeforeMetadata + 1);
    assert.equal(seen.at(-1)?.attempt, 9);
    assert.equal(seen.at(-1)?.currentPath, "A.md");
    assert.deepEqual(seen.at(-1)?.push, { completed: 0, total: 3 });

    setNow(1_000);
    runScheduledCallbackAt(1_000);
    assert.equal(store.snapshot.timings[0].elapsedMs, 1_000);
    assert.equal(store.snapshot.currentPath, "A.md");
    assert.deepEqual(store.snapshot.push, { completed: 0, total: 3 });
    assert.equal(seen.at(-1)?.currentPath, "A.md");
    assert.deepEqual(seen.at(-1)?.push, { completed: 0, total: 3 });

    runScheduledCallbackAt(400);
    assert.equal(store.snapshot.currentPath, scenario.expectedPath);
    assert.deepEqual(store.snapshot.push, { completed: scenario.expectedCompleted, total: 3 });
    assert.equal(seen.at(-1)?.currentPath, scenario.expectedPath);
    assert.deepEqual(seen.at(-1)?.push, { completed: scenario.expectedCompleted, total: 3 });
  });
}

test("actual phase and lifecycle transitions flush pending sensitive state and publish their next state immediately", () => {
  {
    const { store } = createProgressFixture();
    const seen: V4SyncProgressSnapshot[] = [];
    store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 3 } });
    store.subscribe(snapshot => seen.push(snapshot));
    store.update({ currentPath: "B.md", push: { completed: 1 } });

    store.update({ phase: "committing", currentPath: "C.md", push: { completed: 2 } });

    assert.deepEqual(seen.slice(-2).map(snapshot => [snapshot.lifecycle, snapshot.phase, snapshot.currentPath, snapshot.push.completed]), [
      ["active", "uploading", "B.md", 1],
      ["active", "committing", "C.md", 2],
    ]);
  }

  {
    const { store } = createProgressFixture();
    const seen: V4SyncProgressSnapshot[] = [];
    store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 3 } });
    store.subscribe(snapshot => seen.push(snapshot));
    store.update({ currentPath: "B.md", push: { completed: 1 } });

    store.update({ lifecycle: "success", currentPath: "C.md", push: { completed: 2 } });

    assert.deepEqual(seen.slice(-2).map(snapshot => [snapshot.lifecycle, snapshot.phase, snapshot.currentPath, snapshot.push.completed]), [
      ["active", "uploading", "B.md", 1],
      ["success", "uploading", "C.md", 2],
    ]);
  }
});

test("public snapshot is initialized before any working state is published", () => {
  const { store } = createProgressFixture();
  store.update({ currentPath: "unpublished.md", push: { completed: 1 } });

  assert.equal(store.snapshot.currentPath, undefined);
  assert.deepEqual(store.snapshot.push, { completed: 0 });

  let initialForSubscriber: V4SyncProgressSnapshot | undefined;
  store.subscribe(snapshot => { initialForSubscriber ??= snapshot; });
  assert.equal(initialForSubscriber?.currentPath, undefined);
  assert.deepEqual(initialForSubscriber?.push, { completed: 0 });
});

test("getter and first subscriber keep the eligible run snapshot until the exact throttle boundary", () => {
  const { store, runScheduledCallbackAt } = createProgressFixture();
  store.beginRun({ phase: "uploading", currentPath: "A.md", push: { completed: 0, total: 2 } });
  store.update({ currentPath: "B.md", push: { completed: 1 } });

  assert.equal(store.snapshot.currentPath, "A.md");
  assert.deepEqual(store.snapshot.push, { completed: 0, total: 2 });

  const seen: V4SyncProgressSnapshot[] = [];
  store.subscribe(snapshot => seen.push(snapshot));
  assert.equal(seen.at(-1)?.currentPath, "A.md");
  assert.deepEqual(seen.at(-1)?.push, { completed: 0, total: 2 });

  runScheduledCallbackAt(400);
  assert.equal(store.snapshot.currentPath, "B.md");
  assert.deepEqual(store.snapshot.push, { completed: 1, total: 2 });
  assert.equal(seen.at(-1)?.currentPath, "B.md");
  assert.deepEqual(seen.at(-1)?.push, { completed: 1, total: 2 });
});

test("completed timings remain until the next run begins", () => {
  const { store, setNow } = createProgressFixture();
  store.beginRun({ phase: "planning", currentPath: "A.md" });
  setNow(300);
  store.finish("success", { lastSyncTime: 1 });
  const completed = structuredClone(store.snapshot.timings);
  setNow(900);
  store.update({ currentPath: undefined });
  assert.deepEqual(store.snapshot.timings, completed);
  assert.equal(store.snapshot.totalElapsedMs, 300);
  store.beginRun({ phase: "checking-remote" });
  assert.deepEqual(store.snapshot.timings, [{ phase: "checking-remote", elapsedMs: 0, occurrences: 1 }]);
});

test("terminal lifecycle updates freeze elapsed time before later metadata updates", () => {
  for (const lifecycle of ["success", "no-change", "failed"] as const) {
    const { store, setNow } = createProgressFixture();
    store.beginRun({ phase: "committing" });
    setNow(250);
    store.update({ lifecycle });
    assert.equal(store.snapshot.totalElapsedMs, 250, lifecycle);

    setNow(900);
    store.update({ lastSyncTime: 123 });
    assert.equal(store.snapshot.totalElapsedMs, 250, lifecycle);
    assert.deepEqual(store.snapshot.timings, [{ phase: "committing", elapsedMs: 250, occurrences: 1 }], lifecycle);
  }
});

test("beginRun cannot create a terminal lifecycle through runtime patch input", () => {
  for (const lifecycle of ["success", "no-change", "failed"] as const) {
    const { store, scheduled } = createProgressFixture();
    store.beginRun({ lifecycle, phase: "planning" } as V4SyncProgressPatch);

    assert.equal(store.snapshot.lifecycle, "active", lifecycle);
    assert.deepEqual(store.snapshot.timings, [{ phase: "planning", elapsedMs: 0, occurrences: 1 }], lifecycle);
    assert.equal([...scheduled.values()].some(item => item.delay === 1_000), true, lifecycle);
  }
});

test("duration formatting shows sub-tenth and repeated attempts", () => {
  assert.equal(formatV4Duration(50), "<0.1s");
  assert.equal(formatV4Duration(1_240), "1.2s");
  assert.equal(formatV4PhaseTiming({ phase: "checking-remote", elapsedMs: 2_400, occurrences: 2 }), "Checking remote 2.4s · 2 attempts");
});

test("equal patches do not publish duplicate snapshots", () => {
  const { store } = createProgressFixture();
  let deliveries = 0;
  store.subscribe(() => { deliveries += 1; });
  store.update({ lifecycle: "active", phase: "planning" });
  const afterFirstUpdate = deliveries;
  store.update({ lifecycle: "active", phase: "planning", pull: { completed: 0 }, push: { completed: 0 } });
  assert.equal(deliveries, afterFirstUpdate);
});

test("subscriber exceptions do not escape updates or stop other subscribers", () => {
  const { store } = createProgressFixture();
  let delivered = false;
  store.subscribe(() => { throw new Error("subscriber failed"); });
  store.subscribe(() => { delivered = true; });
  assert.doesNotThrow(() => store.update({ lifecycle: "active", phase: "planning" }));
  assert.equal(delivered, true);
});

test("snapshot getter returns deeply frozen copies that cannot mutate store state", () => {
  const { store, setNow } = createProgressFixture();
  store.beginRun({ phase: "uploading", push: { completed: 1, total: 3 } });
  setNow(200);
  store.finish("success");

  const first = store.snapshot;
  const second = store.snapshot;
  assert.notEqual(first.push, second.push);
  assert.notEqual(first.timings, second.timings);
  assert.notEqual(first.timings[0], second.timings[0]);
  assert.equal(Object.isFrozen(first.push), true);
  assert.equal(Object.isFrozen(first.timings), true);
  assert.equal(Object.isFrozen(first.timings[0]), true);
  assert.equal(Reflect.set(first.push, "completed", 99), false);
  assert.equal(Reflect.set(first.timings[0], "elapsedMs", 99), false);
  assert.deepEqual(store.snapshot.push, { completed: 1, total: 3 });
  assert.deepEqual(store.snapshot.timings, [{ phase: "uploading", elapsedMs: 200, occurrences: 1 }]);
});

test("nested mutation attempts in one subscriber cannot affect later subscribers", () => {
  const { store } = createProgressFixture();
  let laterPushCompleted = -1;
  let laterTimingElapsed = -1;
  store.subscribe(snapshot => {
    Reflect.set(snapshot.push, "completed", 99);
    if (snapshot.timings[0]) Reflect.set(snapshot.timings[0], "elapsedMs", 99);
  });
  store.subscribe(snapshot => {
    laterPushCompleted = snapshot.push.completed;
    laterTimingElapsed = snapshot.timings[0]?.elapsedMs ?? -1;
  });

  store.beginRun({ phase: "uploading", push: { completed: 1, total: 3 } });

  assert.equal(laterPushCompleted, 1);
  assert.equal(laterTimingElapsed, 0);
  assert.equal(store.snapshot.push.completed, 1);
  assert.equal(store.snapshot.timings[0].elapsedMs, 0);
});

test("unsubscribe stops later delivery", () => {
  const { store } = createProgressFixture();
  let deliveries = 0;
  const unsubscribe = store.subscribe(() => { deliveries += 1; });
  const beforeUnsubscribe = deliveries;
  unsubscribe();
  store.update({ lifecycle: "active", phase: "planning" });
  assert.equal(deliveries, beforeUnsubscribe);
});

test("dispose cancels pending throttle and timing refresh timers", () => {
  const { store, scheduled, cancelled } = createProgressFixture();
  store.beginRun({ phase: "hashing", currentPath: "A.md" });
  store.update({ currentPath: "B.md" });
  assert.equal(scheduled.size, 2);
  store.dispose();
  assert.equal(scheduled.size, 0);
  assert.equal(cancelled.length, 2);
});

test("a decreasing monotonic clock clamps elapsed deltas at zero", () => {
  const { store, setNow } = createProgressFixture();
  setNow(1_000);
  store.beginRun({ phase: "planning" });
  setNow(500);
  store.finish("success");
  assert.deepEqual(store.snapshot.timings, [{ phase: "planning", elapsedMs: 0, occurrences: 1 }]);
  assert.equal(store.snapshot.totalElapsedMs, 0);
});

test("the progress store has no arbitrary persistence API", () => {
  const { store } = createProgressFixture();
  const candidate = store as unknown as Record<string, unknown>;
  assert.equal(candidate.save, undefined);
  assert.equal(candidate.serialize, undefined);
  assert.equal(candidate.persist, undefined);
  assert.equal(candidate.toJSON, undefined);
});

test("path display keeps both ends while the snapshot retains the full path", () => {
  const path = "Projects/very/long/folder/with/context/important-note.md";
  assert.equal(middleTruncateV4Path(path, 33), "Projects/very/…/important-note.md");
  assert.equal(path, "Projects/very/long/folder/with/context/important-note.md");
});
